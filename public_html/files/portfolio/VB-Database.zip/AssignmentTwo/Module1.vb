
Imports System.Data.OleDb

Module Module1
    ' Variables used with in all the forms
    Public AccountID As Int32
    Public AccName As String
    Public AccSurName As String
    Public cardNumber As String
    Public balance As Int32 ' Store balance number
    Public con As Boolean = False ' Used to make sure that the takeCard() is run only once
    ' Variables used for Account login
    Public tries As Int16 = 0
    Public PINdb As Int16
    Public PIN As Int16
    ' Variables used for database connection
    Public conn As OleDbConnection
    Public comm As OleDbCommand
    Public dr As OleDbDataReader
    Public da As OleDbDataAdapter

    Public Sub connect() ' Public subrutine, becase it is used in many diffrent form it is simpler to create a public sub
        conn = New OleDbConnection
        conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source =|DataDirectory|\Glum.mdb" ' Connect to the Access database
        Try
            conn.Open() ' Open connection
            comm = New OleDbCommand ' Create command object
            comm.Connection = conn ' initlize connection object
            comm.CommandType = CommandType.Text
        Catch ex As Exception
            MessageBox.Show(ex.Message) ' Show error message if one happens
        End Try

    End Sub
    Public Sub takeCard()
        Dim result As Windows.Forms.DialogResult
        result = MessageBox.Show("Please take your Card", "BoGlum", MessageBoxButtons.OKCancel)
        If result <> 1 Then
            connect() ' Useing the subrutine in the module connect to the database.
            comm.CommandText = "UPDATE ATMCards  SET confiscated=yes WHERE cardNumber = '" & cardNumber & "' " ' Create sql command 
            Try
                dr = comm.ExecuteReader ' Send the SQL command to the connection 
                MessageBox.Show("This card " & cardNumber & " has been confiscated", "Card confiscated", MessageBoxButtons.OK, MessageBoxIcon.Error)
                dr.Close() ' End reading from database  
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
            Finally
                conn.Close() ' Allways close the connection to the database  
            End Try
        End If
    End Sub


End Module
