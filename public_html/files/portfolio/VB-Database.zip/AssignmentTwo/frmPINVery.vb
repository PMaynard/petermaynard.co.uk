Public Class frmPINVery
    Private Sub loadCards()
        cmbNonCard.Items.Clear() ' Clears all items in list
        connect() ' Useing the subrutine in the module connect to the database.
        comm.CommandText = "SELECT cardNumber FROM ATMCards WHERE confiscated = false" ''create SQL Command

        Try ' try to run the SQL command
            dr = comm.ExecuteReader()
            While (dr.Read()) '' For each of the rows in the result, untill there are no more
                cmbNonCard.Items.Add(dr.GetValue(0)) ' add the result from the result to the combobox
            End While
            dr.Close() ' End reading from database
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK,MessageBoxIcon.Error) '' Output error message
        Finally
            conn.Close() ' Allways close the connection to the database
        End Try
    End Sub

    Private Sub frmPINVery_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = False
        loadCards() '' Run the loadCards sub
    End Sub

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        If cmbNonCard.SelectedItem <> "" Then
            cardNumber = cmbNonCard.Text

            connect() '' Useing the subrutine in the module connect to the database.
            If cmbNonCard.SelectedItem Then '' Check to make sure that there is a card number selected
                Dim SQL As String = "SELECT PIN FROM ATMCards WHERE cardNumber = '" & cmbNonCard.SelectedItem() & "' "
                'Declare and initilize a string variable then create the 
                ' SQL Command by concatenating the string variable and the selected item from the combo box

                comm.CommandText = SQL ' Execute sql command
                dr = comm.ExecuteReader ' Send the SQL to the connection
                dr.Read() ' Read the data from the database

                PINdb = dr.GetString(0)
                'Set PINdb to the result from the database, there will only ever be on result becase 
                ' cardNumber is the primary key and to inforce referential integrity it has to be unique 
                dr.Close() '' End reading from database
            End If
            conn.Close() '' Allways close the connection to the database
            If IsNumeric(txtPIN.Text) Then ' Check to make sure that the PIN input is numeric
                If txtPIN.Text.Length < 4 Then ' Check to make sure that PIN is four digits
                    MessageBox.Show("PIN Needs to be four digits", "PIN 4 Digits", MessageBoxButtons.OK, MessageBoxIcon.Information) ' Show error message
                Else
                    PIN = txtPIN.Text ''Set the text value of txtPIN to the public variable of PIN
                End If
            Else
                MessageBox.Show("PIN Value must be numeric", "PIN must be numbers", MessageBoxButtons.OK, MessageBoxIcon.Information) ' Show error message
            End If

            If PIN = PINdb And tries < 3 Then
                Me.Hide() ' Hide this form
                frmMenu.ShowDialog() ' Show the next form
                loadCards() ' Reload the card informaiton
            Else
                If tries < 3 Then
                    tries = tries + 1 '' Increass the numeber of tries
                    MessageBox.Show("Incorrect PIN! You have " & 3 - tries & " ammmount of tries left")
                End If
            End If

            If tries >= 3 Then
                connect() ' Useing the subrutine in the module connect to the database.
                Dim SQL As String = "UPDATE ATMCards  SET confiscated=yes WHERE cardNumber = '" & cmbNonCard.SelectedItem & "' "
                comm.CommandText = SQL ' Execute sql command 
                dr = comm.ExecuteReader ' Send the SQL to the connection 
                MessageBox.Show("This card " & cmbNonCard.SelectedItem() & "has been confiscated", "Card confiscated", MessageBoxButtons.OK, MessageBoxIcon.Error)
                dr.Close() ' End reading from database  
                conn.Close() ' Allways close the connection to the database  
                loadCards() ' Run the loadCards sub  
                tries = 0 ' Reset tries to zero  
            End If
        Else
            MessageBox.Show("Select A card from the drop down list", "Select A card", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class
