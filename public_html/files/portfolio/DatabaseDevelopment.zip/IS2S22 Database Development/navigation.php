<!-- Navigation page, is included on all pages to provide a simple navigation system. -->
<p>
<a href="Task3.php">Data Entry Form</a><br>
<a href="Task4.php">View all tables</a><br>
<a href="Task5.php">Delete employee from table</a><br>
<a href="Task6.php">Update Computer data</a><br>
<a href="Task7.php">What employee has which computer</a><br>
</p>
	