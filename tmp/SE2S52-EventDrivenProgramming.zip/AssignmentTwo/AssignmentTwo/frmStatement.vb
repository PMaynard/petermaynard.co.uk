Public Class frmStatement
    Private Sub frmStatement_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lstCard.Items.Clear() ' Clears all items in list
        connect() ' Useing the subrutine in the module connect to the database.
        comm.CommandText = "SELECT cardNumber, transactionType, transactionAmount, transactionDate FROM Log WHERE accountID = " & AccountID & " AND transactionDate >(Int(Now()))-7 ORDER BY transactionDate DESC" ''create SQL Command"

        Try ' try to run the SQL command
            dr = comm.ExecuteReader()
            While (dr.Read()) '' For each of the rows in the result, untill there are no more
                lstCard.Items.Add(dr.GetValue(0)) ' add cardNumber
                lstType.Items.Add(dr.GetValue(1)) ' add transactionType
                lstAmount.Items.Add(dr.GetValue(2)) ' add transactionAmount
                lstDate.Items.Add(dr.GetValue(3)) ' add transactionDate
            End While
            dr.Close() ' End reading from database
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
        Finally
            conn.Close() ' Allways close the connection to the database
        End Try
        ' Set up the form with the new data from the database
        lblAccount.Text = "Account ID: " & AccountID & " " & AccName & " " & AccSurName
        lblBalance.Text = "Current Balance: " & balance
        lblDisplay.Text = "Displaying Statement from " & Now.Day - 7 & "-" & Now.Date

    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        frmMenu.Show() ' Show the next form
        Me.Dispose() ' UnLoad all form in memory 
        Me.Close() ' Close the form
    End Sub

    Private Sub frmStatement_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        frmMenu.Show() ' Show the next form
        Me.Dispose() ' UnLoad all form in memory 
        Me.Close() ' Close the form
    End Sub
End Class