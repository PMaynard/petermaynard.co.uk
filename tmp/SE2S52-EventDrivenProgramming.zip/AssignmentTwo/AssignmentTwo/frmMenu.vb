Public Class frmMenu
    Private Sub updateBalance()
        connect() ' Useing the subrutine in the module connect to the database.
        comm.CommandText = "SELECT balance, overdraftLimit FROM Accounts WHERE accountID = " & AccountID ' create SQL Command, AccountID is an Int theerfore it does not require single quotes around it like strings

        Try ' try to run the SQL command
            dr = comm.ExecuteReader ' Send the SQL to the connection
            dr.Read() ' Read the data from the database
            balance = dr.GetValue(0)
            txtBalance.Text = "Balance is: " & dr.GetValue(0) & " Available: " & dr.GetValue(0) + dr.GetValue(1) ' get and display the data
            dr.Close() ' End reading from database
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
        Finally
            conn.Close() ' Allways close the connection to the database
        End Try
    End Sub
    Private Sub frmMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connect() ' Useing the subrutine in the module connect to the database.
        comm.CommandText = "SELECT * FROM ATMCards WHERE cardNumber = '" & cardNumber & "'" ''create SQL Command
        Try ' try to run the SQL command
            dr = comm.ExecuteReader()
            dr.Read() ' Read the result from the query
            AccountID = dr.GetInt32(2) ' get the accountID
            dr.Close() ' End reading from database
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
        Finally
            conn.Close() ' Allways close the connection to the database
        End Try
    End Sub

    Private Sub frmMenu_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        If con Then ' This is to make sure that there is only one card remove message
            MyBase.Dispose() ' Unload variables
            frmPINVery.Show() ' Show next form
        Else
            takeCard() ' Run the takeCard sub 
            MyBase.Dispose() ' Unload variables
            frmPINVery.Show() ' Show next form
        End If
        con = False
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Close() ' Close the form
    End Sub

    Private Sub btnBalance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBalance.Click
        updateBalance() ' Call the updateBalance sub
    End Sub

    Private Sub btnWithdraw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWithdraw.Click
        Dim total As Int32
        connect() ' Useing the subrutine in the module connect to the database.
        comm.CommandText = "SELECT balance, overdraftLimit FROM Accounts WHERE accountID = " & AccountID ' create SQL Command, AccountID is an Int theerfore it does not require single quotes around it like strings

        Try ' try to run the SQL command
            dr = comm.ExecuteReader ' Send the SQL to the connection
            dr.Read() ' Read the data from the database
            balance = dr.GetValue(0)
            total = balance + dr.GetValue(1)
            dr.Close() ' End reading from database
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
        Finally
            conn.Close() ' Allways close the connection to the database
        End Try

        If txtWithdraw.Text < total And txtWithdraw.Text > 0 Then ' If the text box is zero or greater than total balance display the error message
            ' If this was not here, the user could enter -500 and the account balance would increase, this could be used as a deposit system.

            Dim result As Windows.Forms.DialogResult
            result = MessageBox.Show("Please take your Card", "BoGlum", MessageBoxButtons.OKCancel) ' Prompt remove card 
            If result <> 2 Then
                ' Prompt to remove cash 
                result = MessageBox.Show("Please take your Cash", "BoGlum", MessageBoxButtons.OKCancel)
                If result <> 2 Then
                    ' Debit account
                    Dim SQLWithdraw, SQLLog As String
                    connect() ' Useing the subrutine in the module connect to the database.
                    SQLWithdraw = "UPDATE Accounts SET balance = " & balance - txtWithdraw.Text & " WHERE accountID = " & AccountID ' create SQL Command, AccountID is an Int theerfore it does not require single quotes around it like strings"
                    SQLLog = "INSERT INTO Log (accountID, cardNumber, transactionType, transactionAmount) VALUES( " & AccountID & ", '" & cardNumber & "','W'," & txtWithdraw.Text & ")"

                    Try ' try to run the SQL command
                        comm.CommandText = SQLWithdraw
                        dr = comm.ExecuteReader ' Send the SQL to the connection
                        dr.Close() ' End reading from database

                        comm.CommandText = SQLLog
                        dr = comm.ExecuteReader ' Send the SQL to the connection
                        dr.Close() ' End reading from database
                    Catch ex As Exception
                        MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
                    Finally
                        conn.Close() ' Allways close the connection to the database
                    End Try
                Else
                    MessageBox.Show("No money have been taken, account not debited", "Cash is not gone!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtWithdraw.Text = ""
                End If ' End of prompt to take cash
            Else
                connect() ' Useing the subrutine in the module connect to the database.
                comm.CommandText = "UPDATE ATMCards  SET confiscated=yes WHERE cardNumber = '" & cardNumber & "' " ' Create sql command 
                Try
                    dr = comm.ExecuteReader ' Send the SQL command to the connection 
                    MessageBox.Show("This card " & cardNumber & " has been confiscated", "Card confiscated", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    dr.Close() ' End reading from database  
                Catch ex As Exception
                    MessageBox.Show(ex.Message, "Error with database", MessageBoxButtons.OK, MessageBoxIcon.Error) '' Output error message
                Finally
                    conn.Close() ' Allways close the connection to the database  
                End Try
                con = True
                Close() ' Close the form
            End If ' End of prompt to remove card
            updateBalance() ' Call the update Sub 
        Else
            MessageBox.Show("Isufficient funds")
        End If 'End withdraw > total and > 0
    End Sub

    Private Sub btnStatement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStatement.Click
        updateBalance() ' Call the update Sub 
        Me.Hide() ' Hide the current form
        frmStatement.Show() ' Load the next form
    End Sub
End Class
