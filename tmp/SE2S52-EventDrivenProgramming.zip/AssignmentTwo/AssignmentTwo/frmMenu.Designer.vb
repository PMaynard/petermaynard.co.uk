<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBalance = New System.Windows.Forms.Button
        Me.btnWithdraw = New System.Windows.Forms.Button
        Me.btnStatement = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.txtBalance = New System.Windows.Forms.TextBox
        Me.txtWithdraw = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btnBalance
        '
        Me.btnBalance.Location = New System.Drawing.Point(12, 14)
        Me.btnBalance.Name = "btnBalance"
        Me.btnBalance.Size = New System.Drawing.Size(86, 23)
        Me.btnBalance.TabIndex = 0
        Me.btnBalance.Text = "Balance"
        Me.btnBalance.UseVisualStyleBackColor = True
        '
        'btnWithdraw
        '
        Me.btnWithdraw.Location = New System.Drawing.Point(12, 43)
        Me.btnWithdraw.Name = "btnWithdraw"
        Me.btnWithdraw.Size = New System.Drawing.Size(86, 23)
        Me.btnWithdraw.TabIndex = 1
        Me.btnWithdraw.Text = "Withdraw"
        Me.btnWithdraw.UseVisualStyleBackColor = True
        '
        'btnStatement
        '
        Me.btnStatement.Location = New System.Drawing.Point(12, 83)
        Me.btnStatement.Name = "btnStatement"
        Me.btnStatement.Size = New System.Drawing.Size(86, 23)
        Me.btnStatement.TabIndex = 2
        Me.btnStatement.Text = "Mini statement"
        Me.btnStatement.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(12, 113)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(86, 23)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'txtBalance
        '
        Me.txtBalance.Location = New System.Drawing.Point(104, 17)
        Me.txtBalance.Name = "txtBalance"
        Me.txtBalance.ReadOnly = True
        Me.txtBalance.Size = New System.Drawing.Size(276, 20)
        Me.txtBalance.TabIndex = 4
        '
        'txtWithdraw
        '
        Me.txtWithdraw.Location = New System.Drawing.Point(104, 43)
        Me.txtWithdraw.Name = "txtWithdraw"
        Me.txtWithdraw.Size = New System.Drawing.Size(100, 20)
        Me.txtWithdraw.TabIndex = 5
        Me.txtWithdraw.Text = "0"
        '
        'frmMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(388, 155)
        Me.Controls.Add(Me.txtWithdraw)
        Me.Controls.Add(Me.txtBalance)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnStatement)
        Me.Controls.Add(Me.btnWithdraw)
        Me.Controls.Add(Me.btnBalance)
        Me.MaximumSize = New System.Drawing.Size(396, 182)
        Me.MinimumSize = New System.Drawing.Size(396, 182)
        Me.Name = "frmMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Glumorgan Banking Menu "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBalance As System.Windows.Forms.Button
    Friend WithEvents btnWithdraw As System.Windows.Forms.Button
    Friend WithEvents btnStatement As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents txtWithdraw As System.Windows.Forms.TextBox
    Friend WithEvents txtBalance As System.Windows.Forms.TextBox
End Class
