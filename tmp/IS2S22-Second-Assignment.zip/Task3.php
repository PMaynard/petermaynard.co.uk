<? 
#Task 3 - data entry forms.  
#Call form by useing there respective functions, use the parameters true or false to enable output of all records
function entryComputers($display){
	?>
		<table>
			<form action="<? basename(__FILE__); ?>" method="get">
				<!-- ID<input type="text" name="id"> -->
				<tr><td width="25%">Discription</td><td><input type="text" name="dis"></td>
				<td><input type="submit" name="subComputers" value="Add Record"></td>
			</form>
		</table>
	<?
	// Connect to server and set a database
	$conn = @mysql_connect("localhost","root","root")or die("sorry - could not connect to mysql");
	$rs = @mysql_select_db("inventory",$conn) or die("problem with database");
	
	//Check if form has been submited
	if($_GET['subComputers'] == "Add Record"){
		$ID = $_GET['id'];
		$DIS = $_GET['dis'];
		
		//Create INSERT SQL command
		$sql = "INSERT INTO computers(computerID,computerDescription) values('$ID','$DIS')";
		$rs = mysql_query($sql,$conn);
		echo "<font color=\"#458B00\">Record added to database.</font>";
	//}
	
	//if($display == true){
		//Select and display all records
		$sql = "SELECT * FROM computers ORDER BY computerID DESC LIMIT 0,3";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		
		//echo "\n<h1>Computers</h1>\n";
		echo"<table border=\"1\" width=\"100%\">\n";
		echo "<tr><th>computerID</th><th>Description</th>\n";
		while ($row = mysql_fetch_array($rs))
		{
			echo("<tr>");
			// for each column to be displaywed
			for ($i=0; $i<=1; $i++){
				echo("<td>$row[$i]</td>");
			}
			echo ("</tr>");
		} //end while

		echo ("</table>");
	}
	//close connection
	mysql_close($conn);
} #entryComputers

function entryEmployees($display){
	?>
	<table>
		<form action="<? basename(__FILE__); ?>" method="get">
			<!-- ID<input type="text" name="id"> -->
			<tr><td width="25%">First Name</td><td><input type="text" name="first"></td></tr>
			<tr><td width="25%">Last Name</td><td><input type="text" name="last"></td>
			<td><input type="submit" name="subEmployee" value="Add Record"></td></tr>
		</form>
	</table>
	<?
	// Connect to server and set a database
	$conn = @mysql_connect("localhost","root","root")or die("sorry - could not connect to mysql");
	$rs = @mysql_select_db("inventory",$conn) or die("problem with database");
	
	//Check if form has been submited
	if($_GET['subEmployee'] == "Add Record"){
		$ID = $_GET['id'];
		$FIRST = $_GET['first'];
		$LAST = $_GET['last'];
		
		//Create INSERT SQL command
		$sql = "INSERT INTO employees(employeeID, firstName, lastName) values('$ID','$FIRST','$LAST')";
		$rs = mysql_query($sql,$conn);
		echo "<font color=\"#458B00\">Record added to database.</font>";
	//}
	//if($display == true){
		//Select and display all records
		$sql = "SELECT * FROM employees ORDER BY employeeID DESC LIMIT 0,3";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		
		//echo "\n<h1>Employees</h1>\n";
		echo"<table border=\"1\" width=\"100%\">\n";
		echo "<tr><th>employeeID</th><th>First Name</th><th>Last Name</th>\n";
		while ($row = mysql_fetch_array($rs))
		{
			echo("<tr>");
			for ($i=0; $i<=2; $i++){
				echo("<td>$row[$i]</td>");
			}
			echo ("</tr>");
		} //end while
	}
	echo ("</table>");
	
	//close connection
	mysql_close($conn);
} #entryEmployees

function entryInventory($display){
	// Connect to server and set a database
	$conn = @mysql_connect("localhost","root","root")or die("sorry - could not connect to mysql");
	$rs = @mysql_select_db("inventory",$conn) or die("problem with database");
	?>
	<table>
		<form action="<? basename(__FILE__); ?>" method="get">
			<!-- inventoryID<input type="text" name="id"> -->
			<tr><td width="25%">dateAcquired</td><td><input type="text" name="dateAc"></td></tr>
			<tr><td width="25%">computerID</td><td><select name="computerID">
			<?
			$sql = "SELECT * FROM computers";
			$rs = @mysql_query($sql,$conn) or die("Unable to find records");
			while ($row = mysql_fetch_array($rs))
			{
				echo("		<option value='$row[0]'>[$row[0]] $row[1]</option>\n");
			} //end while
			?>
			</select></td></tr>
			<tr><td width="25%">employeeID</td><td><select name="employeeID">
			<?
			$sql = "SELECT * FROM employees";
			$rs = @mysql_query($sql,$conn) or die("Unable to find records");
			while ($row = mysql_fetch_array($rs))
			{
				echo("		<option value='$row[0]'>[$row[0]] $row[1] $row[2]</option>\n");
			} //end while
			?>
			</select></td></tr>
			<tr><td width="25%">comments</td><td><input type="text" name="comments"></td>
			<td><input type="submit" name="subInventory" value="Add Record"></td></tr>
		</form>
	<table>
	<?
	
	//Check if form has been submited
	if($_GET['subInventory'] == "Add Record"){
		$ID = $_GET['id'];
		$date = $_GET['dateAc'];
		$comp = $_GET['computerID'];
		$empl = $_GET['employeeID'];
		$comments = $_GET['comments'];
		
		//Create SQL command
		$sql = "INSERT INTO inventory(inventoryID, dateAcquired, computerID, employeeID, comments) values('$ID','$date','$comp','$empl','$comments')";
		$rs = mysql_query($sql,$conn);
		echo "<font color=\"#458B00\">Record added to database.</font>";
	//}
	//if($display == true){
		//Select and display all records
		$sql = "SELECT inventoryID, dateAcquired, computerID, firstName, lastName, comments FROM inventory i, employees e WHERE i.employeeID = e.employeeID ORDER BY inventoryID DESC LIMIT 0,3";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		
		//echo "<h1>Inventory</h1>\n";
		echo"<table border=\"1\" width=\"100%\">\n";
		echo "<tr><th>inventoryID</th><th>Date Acquired</th><th>computerID</th><th>First Name</th><th>Last Name</th><th>comments</th></tr>\n";
		while ($row = mysql_fetch_array($rs))
		{
			echo("<tr>");
			for ($i=0; $i<=5; $i++){
				echo("<td>$row[$i]</td>");
			}
			echo ("</tr>");
		} //end while
		echo ("</table>");
	}
	//close connection
	mysql_close($conn);
} #entryInventory
?>

<html>
	<head>	
		<title>Task 3 - data entry and navigation</title>
	</head>
	<body>
	
	<h1>Computer Entry</h1>
	<?php entryComputers(false); ?>
	<h1>Employee Entry</h1>
	<?php entryEmployees(false); ?>
	<h1>Inventory Entry</h1>
	<?php entryInventory(false); 
		@include "navigation.php";
	?>
	</body>
</html>