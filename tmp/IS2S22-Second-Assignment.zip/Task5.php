<html>
	<head>
		<title>Task 5 - Deleting from a Database</title>
	</head>
	<body>
	
	<?php
	$conn = @mysql_connect("localhost","root","root") or die("Sorry - Could not connect to mysql server");
	$rs = @mysql_select_db("inventory",$conn) or die("Problem with database");
	?>
	<table>
	<form action = "<?php basename(__FILE__); ?>" method = "GET">
		<tr><td width="50%">Please select employee to be deleted</td><td><select name="employeeID">
		<?
		$sql = "SELECT * FROM employees ORDER BY employeeID ASC";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		while ($row = mysql_fetch_array($rs))
		{
			echo("		<option value='$row[0]'>[$row[0]] $row[1] $row[2]</option>\n");
		} //end while
		?>
		</select></td>
		<td><input type = "submit" name = "Query" value = "Delete Record"></td></tr>
	</form>
	</table>
	<font color="#8B4500">
	<?php
	$ID = $_GET['employeeID'];
	if($_GET['Query'] == "Delete Record"){
		$sql = "DELETE FROM employees WHERE employeeID = $ID";
		//echo "Employee sql: $sql";
		if((mysql_query($sql,$conn)) && mysql_affected_rows() >= 1)
			echo "<p><b>$ID</b> Employee removed from <i>Employee</i> table";
		
		$sql = "DELETE FROM inventory WHERE employeeID = $ID";
		//echo "Inventory sql: $sql";
		if((mysql_query($sql,$conn)) && mysql_affected_rows() >= 1)
			echo " and <i>inventory</i> table</p>";
	}?>
	</font><?php
	@include "navigation.php";
	//Close connection
	mysql_close($conn);
	?>
	</body>
</html>