<html>
<head>
	<title>Task7 - What employee has which computer</title>
</head>

<body>
<?php
$conn= @mysql_connect("localhost","root","root") or die("Could not connect to local host");
@mysql_select_db("inventory",$conn) or die("Unable to open database");

//Display table inventory
$sql = 'SELECT firstname,lastname,computerDescription, comments FROM computers, employees, inventory '
        . ' WHERE computers.computerID = inventory.computerID AND inventory.employeeID = employees.employeeID ORDER BY `lastname` ASC';
$rs = mysql_query($sql,$conn) or die("No matching records found");
echo "<h1>What employee has which computer</h1>Order by Last Name [ASC]\n";
echo"<table border=\"1\" width=\"100%\">\n";
echo "<tr><th>First Name</th><th>Last Name</th><th>Computer Discription</th><th>Comments</th></tr>\n";
while ($row = mysql_fetch_array($rs))
{
	echo("<tr>");
	for ($i=0; $i<=3; $i++){
		echo("<td>$row[$i]</td>");
	}
	echo ("</tr>\n");
} //end while
	
echo ("</table>\n");


//close conenction 
mysql_close($conn);

@include "navigation.php";
?>
</body>
</html>