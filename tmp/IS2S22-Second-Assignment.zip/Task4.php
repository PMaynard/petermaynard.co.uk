<html>
<head>
	<title>Task4 - Display data in table inventory</title>
</head>

<body>
<h1>Content of Inventory Database</h1>

<?php
$conn= @mysql_connect("localhost","root","root") or die("Could not connect to local host");
@mysql_select_db("inventory",$conn) or die("Unable to open database");

//Display table inventory
$rs = mysql_query("SELECT * FROM inventory", $conn) or die("No matching records found");
echo "<h1>Inventory</h1>\n";
echo"<table border=\"1\" width=\"100%\">\n";
echo "<tr><th>inventoryID</th><th>Date Acquired</th><th>computerID</th><th>employeeID</th><th>comments</th></tr>\n";
while ($row = mysql_fetch_array($rs))
{
	echo("<tr>");
	for ($i=0; $i<=4; $i++){
		echo("<td>$row[$i]</td>");
	}
	echo ("</tr>\n");
} //end while
	
echo ("</table>\n");
	
//Display table employees
$sql = "SELECT * FROM employees";
$rs = @mysql_query($sql,$conn) or die("Unable to find records");

echo "\n<h1>Employees</h1>\n";
echo"<table border=\"1\" width=\"100%\">\n";
echo "<tr><th>employeeID</th><th>First Name</th><th>Last Name</th>\n";
while ($row = mysql_fetch_array($rs))
{
	echo("<tr>");
	for ($i=0; $i<=2; $i++){
		echo("<td>$row[$i]</td>");
	}
	echo ("</tr>\n");
} //end while
echo ("</table>\n");

//Display table computers
$sql = "SELECT * FROM computers";
$rs = @mysql_query($sql,$conn) or die("Unable to find records");

echo "\n<h1>Computers</h1>\n";
echo"<table border=\"1\" width=\"100%\">\n";
echo "<tr><th>computerID</th><th>Description</th>\n";
while ($row = mysql_fetch_array($rs))
{
	echo("<tr>");
	for ($i=0; $i<=1; $i++){
		echo("<td>$row[$i]</td>");
	}
	echo ("</tr>\n");
} //end while
echo ("</table>\n");

//close conenction 
mysql_close($conn);

@include "navigation.php";
?>
</body>
</html>