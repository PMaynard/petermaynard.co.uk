<?php 
function updateComputers($display){
	// Connect to server and set a database
	$conn = @mysql_connect("localhost","root","root")or die("Sorry - Could not connect to mysql");
	$rs = @mysql_select_db("inventory",$conn) or die("Problem with database");

	?>
	<table>
		<form action="<? basename(__FILE__); ?>" method="get" name="getRecord">
		<tr><td width="30%">Choseone to edit</td><td><select name="id">
		<?
		$sql = "SELECT * FROM computers";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		while ($row = mysql_fetch_array($rs))
		{
			echo("<option value='$row[0]'>[$row[0]] $row[1]</option>\n");
		} //end while
		?>
		</select></td>
		<td><input type = "submit" name = "subComputers" value = "Get Record"></td></tr>
		</form>
	<table>
	<?
	//Check if form has been submited
	if($_GET['subComputers'] == "Get Record"  || $_GET['subComputers'] == "Edit Record"){ 
		$ID = $_GET['id'];
		$sql = "SELECT * FROM computers WHERE computerID = $ID";
		$rs = @mysql_query($sql,$conn) or die("Unable to find records");
		$row = mysql_fetch_array($rs);
		?>
		<table>
		<form action="<? basename(__FILE__); ?>" method="get">
			<input type="hidden" name="id" value="<?php echo $row[0] ?>">
			<tr><td width="25%">Discription</td><td><input type="text" name="dis" value="<?php echo $row[1] ?>"></td>
			<td><input type="submit" name="subComputers" value="Edit Record"></td>
		</form>
		</table>
		<?
		//Check if edit form has been submited
		if($_GET['subComputers'] == "Edit Record"){
			$ID = $_GET['id'];
			$DIS = $_GET['dis'];
			
			//Create SQL command
			$sql = "UPDATE computers SET computerDescription = '$DIS' WHERE computerID = '$ID';";
			mysql_query($sql,$conn);
			?> window.alert("Welcome! Press OK to continue."); <?
			echo "<font color=\"#458B00\">Record eddited.</font> <b>From</b>:<i>$row[1]</i> <b>Too</b>:<i>$DIS</i>.<br>";
			//header( 'Location: '. basename(__FILE__) );
		}
	}
	//Close connection
	mysql_close($conn);
}// End function
	
?> 

<html>

<head>
	<title>Task 6 - Update computer data</title>
</head>
<body>
	<?php 
		updateComputers(false); 
		@include "navigation.php";
	?>
</body>
</html>